function sendAI(){
let m=document.getElementById('msg').value;
document.getElementById('chat').innerHTML += '<br>客户:'+m+'<br>AI:已记录您的需求，招商人员会联系您。';
}
function openAI(){
document.getElementById('msg').focus();
}
